
package com.mycompany.mylibrary;

import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class Library {
    
    Scanner in=new Scanner(System.in);
    ArrayList<Shelf> shelves;

    public Library(int numberOfShelves) {
        this.shelves = new ArrayList<>();

        for (int i = 0; i < numberOfShelves; i++) {
            shelves.add(new Shelf()); // إنشاء كل رف
        }
    }

     public void updateBookInfo() {
        String str= JOptionPane.showInputDialog( "What is the number of the BOOK you want to UPDATE it ?");
        //System.out.println("What is the number of the BOOK you want to UPDATE it ?");
        Integer x=Integer.parseInt(str);
        str=JOptionPane.showInputDialog("What is the information about this book you want to update???");
        //System.out.println("What is the information about this book you want to update???");
        //String enterance=in.next();
        
            for (int j = 0; j < shelves.get(x/100-1).books.size(); j++) {
               if(str.equals("titleBook")&&j==(x%100-1)){
                    str=JOptionPane.showInputDialog("enter the new title you want: ");
                     //System.out.println("enter the new title you want: ");
                      shelves.get(x/100-1).books.get(j).setTitleBook(str);
                      break;

                 } 
               else if(str.equals("author")&&j==(x%100-1)){
                    str=JOptionPane.showInputDialog("enter the new AUTHOR you want: ");                   
                     //System.out.println("enter the new AUTHOR you want: ");
                      shelves.get(x/100-1).books.get(j).setAuthor(str);
                      
                      break;

               }
               else if(str.equals("year")&&j==(x%100-1)){
                     str=JOptionPane.showInputDialog("enter the new YEAR you want: ");                                     
                     //System.out.println("enter the new YEAR you want: ");
                     x=Integer.parseInt(str);
                      shelves.get(x/100-1).books.get(j).setYear(x);
                      break;

                 } 
            }
           
    
}
     public Book deleteBook(){
        String str=JOptionPane.showInputDialog("What is the number of the BOOK you want to remove ?");
      //  System.out.println("What is the number of the BOOK you want to remove ?");
        Integer x=Integer.parseInt(str);
        int c=x/100-1;
        int n=0;
        for (int i = 0; i <shelves.get(c).books.size(); i++) {
            if(shelves.get(c).books.get(i).numBook==x)
                n=i;
        }
        return shelves.get(c).books.remove(n);
    }
      public void searchBook(){
        String str= JOptionPane.showInputDialog("What is the Book you want to search about if it is found ? ");

        //System.out.println("What is the Book you want to search about if it is found ? ");
        //str=in.next();
         for (int i = 0; i <5; i++) {
            for (int j = 0; j <shelves.get(i).books.size(); j++) {
                if(shelves.get(i).books.get(j).titleBook.equals(str)){
                    JOptionPane.showMessageDialog(null,"The Book you are looking for is in the library .");
                     //System.out.println("The Book you are looking for is in the library .");
                     return;
                 }
             }
         } 
        JOptionPane.showMessageDialog(null,"The Book you are looking for is not in the library .");
        // System.out.println("The Book you are looking for is not in the library .");

     }
      public void borrowBook(){
       String str= JOptionPane.showInputDialog("What is the title of the BOOK you want to borrow ?" );
       // System.out.println("What is the title of the BOOK you want to borrow ?");
        //str=JOptionPane.showInputDialog();
        for (int i = 0; i < 5 ; i++) {
                
            for (int j = 0; j < shelves.get(i).books.size(); j++) {
            if( shelves.get(i).books.get(j).titleBook.equals(str)){
                shelves.get(i).borrowBook2(str);
                break;}}
        }
      }
      void displayLibrary(){
          String s="";
          for (int i = 0; i < shelves.size(); i++) {
              s+=shelves.get(i).displayBooks()+"\n";
                  
              }
             JOptionPane.showMessageDialog(null, s);
          }
}


    
  
    
    

