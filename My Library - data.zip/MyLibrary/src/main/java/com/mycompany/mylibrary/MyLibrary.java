

package com.mycompany.mylibrary;

import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;



public class MyLibrary {

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        Library library = new Library(5);

        // إضافة بعض الكتب للرفوف
        library.shelves.get(0).addBook(new Book("Book1-A",101, "Author-A",2011));
        library.shelves.get(0).addBook(new Book("Book1-B",102, "Author-B",2000));

        library.shelves.get(1).addBook(new Book("Book2-A",201, "Author-A",1985));

        library.shelves.get(2).addBook(new Book("Book3-A",301, "Author-A",1968));
        library.shelves.get(2).addBook(new Book("Book3-B",302, "Author-B",2004));

        library.shelves.get(3).addBook(new Book("Book4-A",401, "Author-A",1967));

        library.shelves.get(4).addBook(new Book("Book5-A",501, "Author-A",2015));
        library.shelves.get(4).addBook(new Book("Book5-B",502, "Author-B",1999));
        library.shelves.get(4).addBook(new Book("Book5-C",503, "Author-C",1899));

    
    JOptionPane.showMessageDialog(null, "Welcome to your beautiful Library :) ");
    JOptionPane.showMessageDialog(null, "The library contains these books :) ");
        library.displayLibrary();
        
    String str=JOptionPane.showInputDialog("What do you want to do ?"+"\n"+ "Search for a Book __Enter 1"+"\n"+"Delete a Book __Enter 2 "+"\n"+"Display the Books in the Library ___Enter 3"
    +"\n"+"Borrow a Book __Enter 4"+"\n"+"Update book information __Enter 5"+"\n"+"If you do not want to do anything __Enter 0 ");
    Integer x=Integer.parseInt(str);
    while(x!=0){
   
        if(x==1)
        library.searchBook();
        else if(x==2)
        library.deleteBook();
        else if(x==3)
        library.displayLibrary();
        else if (x==4)
        library.borrowBook();
        else if(x==5)
        library.updateBookInfo();
        
        str=JOptionPane.showInputDialog("What do you want to do ?"+"\n"+ "Search for a Book __Enter 1"+"\n"+"Delete a Book __Enter 2 "+"\n"+"Display the Books in the Library ___Enter 3"
    +"\n"+"Borrow a Book __Enter 4"+"\n"+"Update book information __Enter 5"+"\n"+"If you do not want to do anything __Enter 0 ");
     x=Integer.parseInt(str);
    }
        
           
        
    }      
}

    

