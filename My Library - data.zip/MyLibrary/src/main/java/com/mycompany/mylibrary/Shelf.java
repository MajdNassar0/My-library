
package com.mycompany.mylibrary;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Shelf {
    ArrayList<Book> books;
    

    public Shelf() {
        this.books = new ArrayList();
    }
     void addBook(Book book){
        books.add(book);
        
    }
     
     public String displayBooks() {
        String s = "";
        for (int i = 0; i < books.size(); i++) {
            s += "(" + books.get(i).numBook + ")" + " " + books.get(i).titleBook + "  By " + books.get(i).author + " in the Year: " + books.get(i).year + "\n";
            //System.out.println("("+books.get(i).numBook+")"+" "+books.get(i).titleBook+"  By "+books.get(i).author+" in the Year: "+books.get(i).year);
        }
     return s;

    }
   
    
    
    
    
     public void borrowBook2(String titleBook2) {
        for (Book book : books) {
            if (book.titleBook.equals(titleBook2) && !book.isBorrowed()) {
                book.setBorrowed(true);
                JOptionPane.showMessageDialog(null, "You have borrowed " + book.titleBook + ".");
               // System.out.println("You have borrowed " + book.titleBook + ".");
                return;
            }
        }
          JOptionPane.showMessageDialog(null,"Book not available for borrowing." );

        //System.out.println("Book not available for borrowing.");
    }
    
          
    }
