
package com.mycompany.mylibrary;



public class Book {
    String titleBook;
    int numBook;
    String author;
    int year;
    boolean Borrowed=false;

    public Book(String titleBook, int numBook, String author, int year) {
        this.titleBook = titleBook;
        this.numBook = numBook;
        this.author = author;
        this.year = year;
    }

    public Book() {
    }

   

    

    public String getTitleBook() {
        return titleBook;
    }

    public void setTitleBook(String titleBook) {
        this.titleBook = titleBook;
    }

    public int getNumBook() {
        return numBook;
    }

    public void setNumBook(int numBook) {
        this.numBook = numBook;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public boolean isBorrowed() {
        return Borrowed;
    }

    public void setBorrowed(boolean Borrowed) {
        this.Borrowed = Borrowed;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
